<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="tiles32" tilewidth="32" tileheight="32" tilecount="504" columns="24">
 <properties>
  <property name="MY_ID" type="int" value="1"/>
 </properties>
 <image source="../../tiles/tiles32.png" width="768" height="672"/>
</tileset>
